# Run Learnings

Append-only log of ladder cycle outcomes and what changed.
Auto-populated by `scripts/run_ladder.py` via `--learn-log`.

## 2026-04-11T17:06:10+00:00
- Run: `bg_climb_20260411_130405` | range `start -> end` | selected `4` | executed `4` | skipped `0` | failed `0`
- Runtime: `ollama` / `qwen3.5:9b` / `core` | ctx `8192` | CE `0.35` | prompt `a2807206dfc6`
- Actions: executed=4
- Learned:
  - `rung_22_robustness_hard_retarget_lineage`: passed 3/3; parse_fail=0, apply_fail=0, clar_rounds=0; prompt=sp-a2807206dfc6.
  - `rung_23_robustness_hard_repair_bridge`: passed 3/3; parse_fail=0, apply_fail=0, clar_rounds=0; prompt=sp-a2807206dfc6.
  - `rung_24_robustness_hard_passive_retarget`: passed 3/3; parse_fail=0, apply_fail=0, clar_rounds=0; prompt=sp-a2807206dfc6.
  - `rung_25_robustness_hard_branch_preservation`: passed 3/3; parse_fail=0, apply_fail=0, clar_rounds=0; prompt=sp-a2807206dfc6.
