# New rung agent notes

- `rung_210_fuzzy_ce_selective_edge_rebuild`: stresses typo-heavy pronoun clarification, selective retract of one edge while preserving a sibling branch, and rebuilding the path before a follow-up query.
- `rung_220_fuzzy_ce_rule_timing_branch_swap`: stresses noisy pronoun resolution, queries arriving before and after rule ingestion, then a selective branch swap that must preserve the upstream edge and restore downstream ancestry.
