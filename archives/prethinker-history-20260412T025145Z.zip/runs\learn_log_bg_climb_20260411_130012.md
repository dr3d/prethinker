# Run Learnings

Append-only log of ladder cycle outcomes and what changed.
Auto-populated by `scripts/run_ladder.py` via `--learn-log`.

## 2026-04-11T17:03:52+00:00
- Run: `bg_climb_20260411_130012` | range `22 -> 25` | selected `4` | executed `4` | skipped `0` | failed `0`
- Runtime: `ollama` / `qwen3.5:9b` / `core` | ctx `8192` | CE `0.35` | prompt `a2807206dfc6`
- Actions: executed=4
- Learned:
  - `rung_19_robustness_hard_hedged_retarget`: passed 3/3; parse_fail=0, apply_fail=0, clar_rounds=0; prompt=sp-a2807206dfc6.
  - `rung_20_robustness_hard_inversion_chain`: passed 2/2; parse_fail=0, apply_fail=0, clar_rounds=0; prompt=sp-a2807206dfc6.
  - `rung_21_robustness_hard_hedged_retract_shift`: passed 3/3; parse_fail=0, apply_fail=0, clar_rounds=0; prompt=sp-a2807206dfc6.
  - `rung_22_robustness_hard_retarget_lineage`: passed 3/3; parse_fail=0, apply_fail=0, clar_rounds=0; prompt=sp-a2807206dfc6.
