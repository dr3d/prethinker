# Run Learnings

Append-only log of ladder cycle outcomes and what changed.
Auto-populated by `scripts/run_ladder.py` via `--learn-log`.

## 2026-04-11T17:09:44+00:00
- Run: `bg_widespaced_20260411_130857` | range `start -> end` | selected `4` | executed `3` | skipped `0` | failed `1`
- Runtime: `ollama` / `qwen3.5:9b` / `core` | ctx `8192` | CE `0.35` | prompt `a2807206dfc6`
- Actions: executed=3
- Learned:
  - `rung_35_robustness_hard_passive_voice_repair`: passed 3/3; parse_fail=0, apply_fail=0, clar_rounds=0; prompt=sp-a2807206dfc6.
  - `rung_35_spacing_passive_direction_repair`: passed 3/3; parse_fail=0, apply_fail=0, clar_rounds=0; prompt=sp-a2807206dfc6.
  - `rung_40_robustness_hard_hedged_inversion_bundle`: subprocess failed (return code 1).
