# New rung notes

- `rung_180_ce_noisy_pronoun_reverse_guard`: stresses typo-heavy pronoun clarification, noisy follow-up querying, and cleanup of a possible reversed edge without disturbing the intended chain.
- `rung_190_ce_midstream_retarget_queries`: stresses interleaved query-before-repair and query-after-repair behavior, with a clarification-driven selective retract followed by chain rebuilding.
- `rung_200_ce_selective_branch_repair_queries`: stresses denser mixed ingest/query context, selective branch repair under noisy English, and preservation of a sibling branch while rerouting another path.
